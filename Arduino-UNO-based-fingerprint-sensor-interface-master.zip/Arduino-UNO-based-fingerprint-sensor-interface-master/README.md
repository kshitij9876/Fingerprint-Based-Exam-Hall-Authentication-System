Description:
Here is an implementation of fingerprint sensor interface with Arduino Uno board. For input we used Four push buttons. The menu on LCD guides the enrollment and scanning process. 

Components

Arduino Board Uno R3

Finger Print Sensor (https://www.adafruit.com/product/751)

Liquid Crystal Display 16×2

Connecting Wires
